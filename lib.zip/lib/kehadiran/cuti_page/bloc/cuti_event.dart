part of 'cuti_bloc.dart';

abstract class CutiEvent extends Equatable {
  const CutiEvent();

  @override
  List<Object> get props => [];
}

class CutiFetchedEvent extends CutiEvent {
  final int userId;
  const CutiFetchedEvent({required this.userId});
}

class UpdateCutiEvent extends CutiEvent {
  final String id;
  final int userId;
  final String kategori;
  final String tanggal_mulai;
  final String tanggal_selesai;
  final String alasan;
  final String berkas;
  final String jenis_cuti;
  final CutiModel cutiModel;

  const UpdateCutiEvent({required this.id, required this.userId, required this.kategori,
    required this.tanggal_mulai, required this.tanggal_selesai, required this.alasan,
    required this.berkas, required this.cutiModel, required this.jenis_cuti});
}

class DeleteCutiEvent extends CutiEvent {
  final String id;
  final int userId;
  const DeleteCutiEvent({required this.id, required this.userId});
}



class AddCutiEvent extends CutiEvent {
  final int userId;
  final String kategori;
  final String tanggal_mulai;
  final String tanggal_selesai;
  final String alasan;
  final String berkas;
  final String jenis_cuti;
  final CutiModel cutiModel;

  const AddCutiEvent({required this.userId, required this.kategori,
    required this.tanggal_mulai, required this.tanggal_selesai, required this.alasan,
    required this.berkas, required this.cutiModel, required this.jenis_cuti});
}
